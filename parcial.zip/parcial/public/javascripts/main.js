dulces();
document.forms.formadd.addEventListener("submit",function (e){
 e.preventDefault();
 let data = {
     iddulce:document.querySelector("#id")
 }   
}